#include "apc.h"                      // Include header file

void multiplication(node *tail1, node *tail2, node **headR1, node **tailR1)
{
    node *temp2 = tail2;             // Pointer for operand2 (LSB)
    int count = 0;                   // Tracks position for shifting zeros

    while (temp2 != NULL)            // Loop through each digit of operand2
    {
        node *temp1 = tail1;         // Pointer for operand1 (LSB)
        node *headR2 = NULL;         // Temporary result list
        node *tailR2 = NULL;         // Tail for temporary result

        int carry = 0;               // Carry for multiplication

        while (temp1 != NULL)        // Multiply each digit of operand1
        {
            int prdt = (temp1->data * temp2->data) + carry; // Multiply + carry

            insert_first(&headR2, &tailR2, prdt % 10);      // Store unit digit
            carry = prdt / 10;                              // Update carry

            temp1 = temp1->prev;        // Move to previous digit
        }

        if (carry > 0)                 // Check remaining carry
        {
            insert_first(&headR2, &tailR2, carry); // Insert carry
        }

        for (int i = 0; i < count; i++) // Add shifting zeros
        {
            insert_last(&headR2, &tailR2, 0); // Append zero
        }

        if (*headR1 == NULL)           // If result list is empty
        {
            *headR1 = headR2;          // Assign first partial result
            *tailR1 = tailR2;
        }
        else
        {
            node *head_AR = NULL;      // Head for addition result
            node *tail_AR = NULL;      // Tail for addition result

            addition(tailR2, *tailR1, &head_AR, &tail_AR); // Add partial result

            delete_list(headR1, tailR1); // Delete old result list

            *headR1 = head_AR;         // Update result head
            *tailR1 = tail_AR;         // Update result tail

            delete_list(&headR2, &tailR2); // Delete temp list
        }

        temp2 = temp2->prev;          // Move to next digit of operand2
        count++;                      // Increase zero shift count
    }
}