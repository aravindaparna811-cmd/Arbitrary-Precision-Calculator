#include "apc.h"                      // Include header file

void addition(node *tail1, node *tail2, node **headR, node **tailR)
{
    node *temp1 = tail1;             // Pointer for operand1 (LSB)
    node *temp2 = tail2;             // Pointer for operand2 (LSB)

    int sum = 0, carry = 0;          // Initialize sum and carry

    while (temp1 != NULL || temp2 != NULL || carry != 0) // Loop until all digits processed
    {
        sum = carry;                 // Start with previous carry

        if (temp1 != NULL)           // Check operand1 digit
        {
            sum = sum + temp1->data; // Add operand1 digit
            temp1 = temp1->prev;     // Move to previous digit
        }

        if (temp2 != NULL)           // Check operand2 digit
        {
            sum = sum + temp2->data; // Add operand2 digit
            temp2 = temp2->prev;     // Move to previous digit
        }

        carry = sum / 10;            // Calculate carry
        sum   = sum % 10;            // Get single digit

        insert_first(headR, tailR, sum); // Insert result digit at front
    }
}