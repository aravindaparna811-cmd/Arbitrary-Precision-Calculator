/*APARNA A
DATE : 03/ 04/2026
PROJECT :Arbitrary Precision Calculator
DESCRIPTION: Arbitrary Precision Calculator (APC) is a program that performs arithmetic operations on numbers of unlimited size.
It uses data structures like linked lists to store each digit and process calculations step by step.
This allows accurate computation of very large numbers beyond the limits of standard data types.
 SAMPLE INPUT & OUTPUT :./a.out -50 + 20 = -30
                        ./a.out 10 / 0 = Error: Division by zero
                        ./a.out 100 / 5 = 20
                        ./a.out 25 x 4 = 100
                        ./a.out 1000 - 250 = 750
                        ./a.out 123 + 456 = 579

*/  
#include "apc.h"                                             // Include header file with structure and function declarations

int positive_flag1 = 0, negative_flag1 = 0;                 // Flags for operand1 sign
int positive_flag2 = 0, negative_flag2 = 0;                 // Flags for operand2 sign

int main(int argc, char *argv[])
{
    node *head1 = NULL, *tail1 = NULL;                      // Linked list for operand1
    node *head2 = NULL, *tail2 = NULL;                      // Linked list for operand2
    node *headR = NULL, *tailR = NULL;                      // Linked list for result

    // Validation
    if (cla_validation(argc, argv) == FAILURE)              // Validate command line arguments
    {
        return FAILURE;                                     // Exit if invalid input
    }

    // Decide sign
    operation_decider(argv[1], argv[3]);                    // Set sign flags for operands

    // Remove sign before list creation
    char *op1 = (argv[1][0] == '-' || argv[1][0] == '+') ? argv[1] + 1 : argv[1];  // Skip sign for operand1
    char *op2 = (argv[3][0] == '-' || argv[3][0] == '+') ? argv[3] + 1 : argv[3];  // Skip sign for operand2

    // Create lists
    create_list(op1, &head1, &tail1);                        // Convert operand1 string to linked list
    create_list(op2, &head2, &tail2);                        // Convert operand2 string to linked list

    // Remove leading zeros
    remove_pre_zeros(&head1);                                // Remove leading zeros in operand1
    remove_pre_zeros(&head2);                                // Remove leading zeros in operand2

    char oper = argv[2][0];                                  // Store operator (+, -, *, /)

    switch (oper)
    {
    case '+':                                                // Addition case
    { 
        if (positive_flag1 && positive_flag2)                // + + case
        {
            addition(tail1, tail2, &headR, &tailR);          // Perform addition
        }
        else if (negative_flag1 && negative_flag2)           // - - case
        {
            addition(tail1, tail2, &headR, &tailR);         // Add 
            printf("-");                                    // Result is negative
        }
        else if (positive_flag1 && negative_flag2)          // + - case
        {
            int ret = compare_list(head1, head2);           // Compare magnitudes

            if (ret == OPERAND1)                             // op1 > op2
                subtraction(tail1, tail2, &headR, &tailR);   // op1 - op2
            else if (ret == OPERAND2)                        // op2 > op1
            {
                subtraction(tail2, tail1, &headR, &tailR);   // op2 - op1
                printf("-");                                // Result negative
            }
            else
                insert_first(&headR, &tailR, 0);            // Equal → result 0
        }
        else if (negative_flag1 && positive_flag2)          // - + case
        {
            int ret = compare_list(head1, head2);          // Compare magnitudes

            if (ret == OPERAND1)                           // op1 > op2
            {
                subtraction(tail1, tail2, &headR, &tailR);  // op1 - op2
                printf("-");                                // Result negative
            }
            else if (ret == OPERAND2)                        // op2 > op1
            {
                subtraction(tail2, tail1, &headR, &tailR);  // op2 - op1
            }
            else
                insert_first(&headR, &tailR, 0);            // Equal → result 0
        }
        break;   
    }

    case '-':                                               // Subtraction case
    {    
        if (positive_flag1 && positive_flag2)               // + - + case
        {
            int ret = compare_list(head1, head2);            // Compare values

            if (ret == OPERAND1)                            // op1 > op2
            {
                subtraction(tail1, tail2, &headR, &tailR);  // op1 - op2
            }
            else if (ret == OPERAND2)                       // op2 > op1
            {
                subtraction(tail2, tail1, &headR, &tailR);  // op2 - op1
                printf("-");                                // Result negative
            }
            else
            {
                insert_first(&headR, &tailR, 0);            // Equal → 0
            }
        }
        else if (positive_flag1 && negative_flag2)          // + - (-)
        {
            addition(tail1, tail2, &headR, &tailR);        // Convert to addition
        }
        else if (negative_flag1 && positive_flag2)         // - - (+)
        {
            addition(tail1, tail2, &headR, &tailR);       // Add magnitudes
            printf("-");                                  // Result negative
        }
        else if (negative_flag1 && negative_flag2)        // (- )-(-) 
        {  
            int ret = compare_list(head1, head2);          // Compare values

            if (ret == OPERAND1)                           // op1 > op2
            {
                subtraction(tail1, tail2, &headR, &tailR);  // op1 - op2
                printf("-");                               // Result negative
            }
            else if (ret == OPERAND2)                       // op2 > op1
            {
                subtraction(tail2, tail1, &headR, &tailR);  // op2 - op1
            }
            else
            {
                insert_first(&headR, &tailR, 0);             // Equal → 0
            }
        }
        break;
    }

    case 'x':                                               // Multiplication case
    case 'X':
    {
        multiplication(tail1, tail2, &headR, &tailR);       // Multiply numbers

        if ((positive_flag1 && negative_flag2) || (negative_flag1 && positive_flag2))
            printf("-");                                    // Result negative if signs differ
        break;
    }

    case '/':                                               // Division case
    {
        division(head1, head2, tail2, &headR, &tailR);       // Perform division

        if ((positive_flag1 && negative_flag2) || (negative_flag1 && positive_flag2))
            printf("-");                                    // Result negative if signs differ
        break;
    }

    default:
        printf("Invalid operator\n");                        // Handle invalid operator
    }

    remove_pre_zeros(&headR);                                // Remove leading zeros in result
    print_list(headR);                                      // Print result list
    printf("\n");                                         
}