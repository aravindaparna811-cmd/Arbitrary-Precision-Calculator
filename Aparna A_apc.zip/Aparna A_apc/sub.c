#include "apc.h"                 // Include header file

void subtraction(node *tail1, node *tail2, node **headR, node **tailR)
{
    int flag = 0;               // Borrow flag

    node *temp1 = tail1;        // Pointer for operand1 (LSB)
    node *temp2 = tail2;        // Pointer for operand2 (LSB)

    int sub;                    // Store subtraction result

    while (temp1 != NULL)       // Loop until operand1 ends
    {
        int num1 = temp1->data; // Get digit from operand1
        int num2;               // Declare digit for operand2

        if (temp2 != NULL)      // Check operand2 digit
            num2 = temp2->data; // Assign operand2 digit
        else
            num2 = 0;           // If NULL, assign 0

        num1 = num1 - flag;     // Subtract previous borrow

        if (num1 < num2)        // Check if borrow needed
        {
            sub = (num1 + 10) - num2;     // Perform borrow subtraction
            flag = 1;                    // Set borrow flag
        }
        else
        {
            sub = num1 - num2;           // Normal subtraction
            flag = 0;                    // Reset borrow flag
        }

        insert_first(headR, tailR, sub); // Insert result at front

        temp1 = temp1->prev;             // Move to previous digit (operand1)

        if (temp2 != NULL)               // Check operand2 pointer
            temp2 = temp2->prev;        // Move to previous digit (operand2)
    }
}