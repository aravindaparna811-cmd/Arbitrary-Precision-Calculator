#include "apc.h"                                           // Include header file

int division(node *head1_L1, node *head2_OPR2, node *tail2_OPR2, node **headR, node **tailR)
{
    node *head_OPR1 = NULL, *tail_OPR1 = NULL;             // Temporary dividend (current working part)
    node *head_SR = NULL, *tail_SR = NULL;                  // Stores subtraction result

    node *L1_temp = head1_L1;                               // Pointer to traverse operand1

    int count = 0;                                         // Stores quotient digit

    if (head2_OPR2->data == 0 && head2_OPR2->next == NULL)   // Check division by zero
    {
        printf("Error: Division by zero\n");                 // Print error
        return 0;   // Exit
    }

    if (compare_list(head1_L1, head2_OPR2) == OPERAND2)     // If operand1 < operand2
    {
        insert_first(headR, tailR, 0);                      // Quotient is 0
        return 0;   // Exit
    }

    // STEP 1: Build initial OPR1
    insert_last(&head_OPR1, &tail_OPR1, L1_temp->data);       // Insert first digit

    while (compare_list(head_OPR1, head2_OPR2) == OPERAND2)   // While OPR1 < divisor
    {
        L1_temp = L1_temp->next;                               // Move to next digit

        if (L1_temp == NULL)                                    // If no more digits
            break;

        insert_last(&head_OPR1, &tail_OPR1, L1_temp->data);      // Append digit
        remove_pre_zeros(&head_OPR1);                           // Remove leading zeros
    }

    if (L1_temp != NULL)
        L1_temp = L1_temp->next;                                // Move to next digit for main loop

    // MAIN LOOP
    while (L1_temp != NULL)                                     // Process remaining digits
    {
        count = 0;                                              // Reset quotient digit

        // Continuous subtraction
        while (compare_list(head_OPR1, head2_OPR2) != OPERAND2)   // While OPR1 >= divisor
        {
            subtraction(tail_OPR1, tail2_OPR2, &head_SR, &tail_SR);  // OPR1 - divisor

            delete_list(&head_OPR1, &tail_OPR1);                    // Delete old OPR1

            head_OPR1 = head_SR;                                    // Update OPR1 with result
            tail_OPR1 = tail_SR;

            head_SR = NULL;                                         // Reset subtraction result
            tail_SR = NULL;

            remove_pre_zeros(&head_OPR1);                           // Remove leading zeros

            count++;                                                // Increment quotient digit
        }

        // Store quotient digit
        insert_last(headR, tailR, count);                           // Add digit to result

        // Bring next digit
        insert_last(&head_OPR1, &tail_OPR1, L1_temp->data);         // Append next digit
        remove_pre_zeros(&head_OPR1);                               // Clean zeros

        L1_temp = L1_temp->next;                                    // Move forward
    }

    // FINAL STEP (VERY IMPORTANT)
    count = 0;                                                      // Reset count
    while (compare_list(head_OPR1, head2_OPR2) != OPERAND2)        // Final subtraction
    {
        subtraction(tail_OPR1, tail2_OPR2, &head_SR, &tail_SR);   // OPR1 - divisor

        delete_list(&head_OPR1, &tail_OPR1);            // Delete old OPR1

        head_OPR1 = head_SR;                             // Update OPR1
        tail_OPR1 = tail_SR;

        head_SR = tail_SR = NULL;                       // Reset temp pointers

        remove_pre_zeros(&head_OPR1);                   // Remove zeros

        count++;                                        // Increment quotient digit
    }

    insert_last(headR, tailR, count);                  // Store last quotient digit

    remove_pre_zeros(headR);                          // Clean result

    return 1;                                        // Success
}