#ifndef APC_H
#define APC_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#define SUCCESS		1
#define FAILURE		0

#define SAME		0
#define OPERAND1	1
#define OPERAND2	2

typedef struct node
{
    struct node *prev;                                                                      // Pointer to previous node (for doubly linked list)
    int data;                                                                               // Stores a single digit of the number
    struct node *next;                                                                      // Pointer to next node
} node;                                                                                     // Structure name as 'node'

void addition(node *tail1, node *tail2, node **headR, node **tailR);                         // Function to add two numbers
void subtraction(node *tail1, node *tail2, node **headR, node **tailR);                      // Function to subtract two numbers
void multiplication(node *tail1, node *tail2, node **headR, node **tailR);                   // Function to multiply two numbers
int division(node *headl1, node *head_opr2, node *tail_opr2, node **headR, node **tailR);   // Function to divide two numbers

int cla_validation(int argc, char *argv[]);                              // Validates command line arguments
void create_list(char *opr, node **head, node **tail);                   // Converts string operand into linked list

extern int positive_flag1, negative_flag1;                                // External flags for operand1 sign
extern int positive_flag2, negative_flag2;                               // External flags for operand2 sign

void operation_decider(char *op1, char *op2);                            // Determines sign of operands

int insert_first(node **head, node **tail, int data);                    // Insert node at beginning
int insert_last(node **head, node **tail, int data);                    // Insert node at end
int delete_list(node **head, node **tail);                              // Delete entire list

void print_list(node *head);                                            // Print linked list (number)

int compare_list(node *head1, node *head2);                             // Compare two numbers (lists)
int list_len(node *head);                                               // Find length of linked list
void remove_pre_zeros(node **head);                                    // Remove leading zeros from number

#endif                                                                 // End of header file